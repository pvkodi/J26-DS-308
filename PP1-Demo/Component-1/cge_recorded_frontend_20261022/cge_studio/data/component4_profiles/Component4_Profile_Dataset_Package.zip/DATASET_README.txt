COMPONENT 4 PROFILE DATASET —21 OCTOBER2026

Open Component4_Profile_Dataset.xlsx for the presentation. Summary shows measured
factor changes. Examples contains two authentic paired demonstrations. Answers
has384 actual generations; Obligation checks has1536 focal-rule observations.
Use Conditions to explain the12 controlled treatments and Dictionary for columns.
Tables are filterable. Long answers remain complete in their cells;select a cell
or use the Examples sheet to read a response comfortably. This is a fixed export.
Editing raw rows does not rerun the external grouped-profile analysis.

CSV alternatives:answers.csv(384),obligation_checks.csv(1536),all_rule_checks.csv
(1920 including competing rules),conditions.csv,factor_results.csv,natural_results.csv,
data_dictionary.csv. CSV is UTF-8 with BOM for Excel. Empty failure labels are
censored/missing,not zero. Four focal checks belong to the same answer.

full_records.jsonl retains all384 original record objects,including complete
system prompts,previous messages,answers,active rules,checks,model identifiers,
seeds,timings and hashes. input_commitments.jsonl retains384 pre-generation
commitments. Nothing in those records was rewritten for presentation.

288 controlled generated answers use authored all-rules-compliant histories.
96 natural answers belong to8 freely generated12-answer conversations across
two models. Every preceding controlled assistant example passes all8 formats,
including when only4 rules are currently mandatory. This common scaffold helps
matching but can prime the output style. Actual later replies are generated.

One Granite controlled long-context answer reached768 tokens and contains546
counted words. It is not a clean pass. It remains in raw evidence;its4 focal rows
are excluded from primary completed-answer estimates.383 answers and1532 focal
checks are primary-valid. The original protocol was not changed after results.

Source checkpoint SHA256:
badea52a0841939539f68d46c331d5490eb3f58c491616c7529f620d62facfaa
The original archive was audited for hashes,inputs,history chains,checker outcomes
and profile estimates. Hashes show consistency,not external certification.

Scores are conditional empirical differences,not classifier probabilities.
0.20 means20 percentage points more focal-rule failures under that comparison.
Use signed effects alongside harmful scores. These are separate Component4
profiles. The existing risk predictor and its calibration profiles are unchanged.
